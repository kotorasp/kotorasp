package by.legan.lesons.telegrambot.telegrambotgitea;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TelegramBotGiteaApplicationTests {

    // @Test
    void contextLoads() {
    }

}
